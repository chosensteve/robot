/*
 * Air Quality Node - ESP32-C3
 * PM2.5 Simulation: GPIO 4 (ADC1_CH4)
 * MQ-135 Simulation: GPIO 3 (ADC1_CH3)
 */

#define PM25_PIN 4
#define MQ135_PIN 3

// Calibration Constants
const float V_REF = 3.3;        // ESP32-C3 operating voltage
const int ADC_RES = 4095;      // 12-bit resolution
const float DUST_SLOPE = 0.17; // Typical slope for GP2Y sensor

void setup() {
  Serial.begin(115200);
  analogReadResolution(12); // Set ADC to 12-bit
  
  pinMode(PM25_PIN, INPUT);
  pinMode(MQ135_PIN, INPUT);
}

void loop() {
  // --- 1. PM2.5 SENSOR (Dust Density) ---
  int rawPM = analogRead(PM25_PIN);
  float voltagePM = rawPM * (V_REF / ADC_RES);
  
  // Formula: Dust Density (mg/m3) = 0.17 * V - 0.1
  float dustDensity = (DUST_SLOPE * voltagePM);
  if (dustDensity < 0) dustDensity = 0; // Prevent negative readings from noise

  // --- 2. MQ-135 SENSOR (Gas Concentration) ---
  int rawMQ = analogRead(MQ135_PIN);
  // Simulating a PPM (Parts Per Million) range from 0 to 1000
  int airPPM = map(rawMQ, 0, ADC_RES, 0, 1000);

  // --- 3. OUTPUT & CATEGORIZATION ---
  printStatus(dustDensity, airPPM);

  delay(1500); // Wait 1.5 seconds for readability
}

void printStatus(float dust, int ppm) {
  Serial.print("|PM2.5: ");
  Serial.print(dust, 3);
  Serial.print(" mg/m3 | ");

  Serial.print("MQ-135: ");
  Serial.print(ppm);
  Serial.print(" PPM |");

  Serial.println("\n");
}